# Crie a pasta 'ai' no seu backend Django e adicione este código.

import numpy as np

def ajustar_treino(historico_treinos):
    """
    Ajusta o treino com base no histórico do usuário.
    Entrada: histórico_treinos (lista de dicionários com cargas, reps, etc.)
    Saída: Novo treino ajustado
    """
    if not historico_treinos:
        return {"carga": 10, "reps": 10}  # Valor inicial

    # Pegando a carga média dos últimos treinos
    cargas = [treino["carga"] for treino in historico_treinos]
    media_carga = np.mean(cargas)

    # Regra inicial: aumentar a carga em 5%
    nova_carga = media_carga * 1.05

    return {"carga": round(nova_carga, 2), "reps": 10}
