# accounts/serializers.py
from rest_framework import serializers
from django.contrib.auth import get_user_model
from datetime import date

User = get_user_model()
class UserSerializer(serializers.ModelSerializer):
    age = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'age', 'weight', 'height', 'fitness_goal', 'dietary_restrictions']

    def get_age(self, obj):
        if obj.birth_date:
            today = date.today()
            return today.year - obj.birth_date.year - ((today.month, today.day) < (obj.birth_date.month, obj.birth_date.day))
        return None

    def validate_weight(self, value):
        if value <= 0:
            raise serializers.ValidationError("O peso deve ser um valor positivo.")
        return value

    def validate_height(self, value):
        if value <= 0:
            raise serializers.ValidationError("A altura deve ser um valor positivo.")
        return value

    def validate_fitness_goal(self, value):
        valid_goals = ['perda de peso', 'ganho muscular', 'manutenção']
        if value not in valid_goals:
            raise serializers.ValidationError(f"Objetivo de fitness inválido. Os valores válidos são: {', '.join(valid_goals)}")
        return value