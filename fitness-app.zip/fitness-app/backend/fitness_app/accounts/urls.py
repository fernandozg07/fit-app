from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework.routers import DefaultRouter
from .views import register_user  # Importando a view de registro
from accounts.views import UserViewSet  # Importando o UserViewSet

# Configurando o router para os endpoints do UserViewSet
router = DefaultRouter()
router.register(r'users', UserViewSet)

urlpatterns = [
    # Endpoint para registrar um novo usuário
    path('register/', register_user, name='register_user'),
    
    # Endpoints de autenticação JWT
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # Incluindo os endpoints registrados pelo router
    path('api/', include(router.urls)),
]
