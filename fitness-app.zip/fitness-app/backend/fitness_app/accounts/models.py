from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    FITNESS_GOALS = [
        ('perda de peso', 'Perda de Peso'),
        ('ganho muscular', 'Ganho Muscular'),
        ('flexibilidade', 'Flexibilidade'),
    ]
    birth_date = models.DateField(null=True, blank=True)  # Campo de data de nascimento
    weight = models.FloatField(null=True, blank=True)     # Peso
    height = models.FloatField(null=True, blank=True)     # Altura
    fitness_goal = models.CharField(max_length=50, choices=FITNESS_GOALS, blank=True, null=True)  # Objetivo fitness
    dietary_restrictions = models.TextField(null=True, blank=True)  # Restrições alimentares

    def __str__(self):
        return self.username
