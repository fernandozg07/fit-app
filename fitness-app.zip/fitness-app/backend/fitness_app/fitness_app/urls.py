from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),  # Rota para o painel administrativo
    path('accounts/', include('accounts.urls')),  # Incluindo URLs da app 'accounts'
    path('diets/', include('diets.urls')),  # Incluindo URLs da app 'diets'
    path('workouts/', include('workouts.urls')),  # Incluindo URLs da app 'workouts'
]
