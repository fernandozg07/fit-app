from __future__ import absolute_import, unicode_literals
import os
import django  # Certifique-se que o Django está configurado
from celery import Celery

# Configura o Django para ser usado com o Celery
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'fitness_app.settings')
django.setup()

# Criação da instância do Celery
app = Celery('fitness_app')

# Carrega as configurações do Celery a partir do arquivo settings.py
app.config_from_object('django.conf:settings', namespace='CELERY')

# Permite reconexão automática com o broker
app.conf.broker_connection_retry_on_startup = True

# Descobre automaticamente as tasks registradas no projeto
app.autodiscover_tasks()

# Função de depuração para testar tarefas do Celery
@app.task(bind=True)
def debug_task(self):
    print(f"Request: {self.request!r}")
