from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from datetime import timedelta
from .models import Workout, WorkoutLog, WorkoutFeedback
from .serializers import WorkoutSerializer
from ai.trainer import ajustar_treino  # Importando a IA
from .tasks import send_workout_reminder

from rest_framework import viewsets

# Definindo o WorkoutViewSet
class WorkoutViewSet(viewsets.ModelViewSet):
    queryset = Workout.objects.all()  # Defina a consulta para buscar todos os workouts
    serializer_class = WorkoutSerializer  # Defina o serializer para o Workout

# Função fictícia de IA para ajustar os treinos com base no feedback
def adjust_workout_based_on_feedback(workout, feedback_rating):
    if feedback_rating >= 4:
        if 'musculacao' in workout.workout_type:
            workout.intensity = 'Alta'
            workout.duration += timedelta(minutes=15)
        elif 'cardio' in workout.workout_type:
            workout.intensity = 'Moderada'
            workout.duration += timedelta(minutes=10)
    else:
        if feedback_rating <= 2:
            workout.intensity = 'Baixa'
            workout.duration = max(timedelta(minutes=30), workout.duration - timedelta(minutes=10))
    return workout

@api_view(['POST'])
def generate_workout(request):
    user = request.user
    fitness_goal = request.data.get('fitness_goal')

    if not fitness_goal:
        return Response({'detail': 'Goal não encontrado na requisição.'}, status=status.HTTP_400_BAD_REQUEST)

    workout_options = {
        'perda de peso': {
            'workout_type': 'cardio',
            'intensity': 'Alta',
            'duration': timedelta(minutes=45),
            'exercises': 'Corrida, Bicicleta, Pular corda',
            'series_reps': '',
            'frequency': '5 vezes por semana'
        },
        'ganho muscular': {
            'workout_type': 'musculacao',
            'intensity': 'Moderada',
            'duration': timedelta(hours=1),
            'exercises': 'Supino, Agachamento, Levantamento terra, Flexões',
            'series_reps': '3 séries de 12 repetições por exercício',
            'frequency': '3 vezes por semana'
        },
        'flexibilidade': {
            'workout_type': 'flexibilidade',
            'intensity': 'Baixa',
            'duration': timedelta(minutes=30),
            'exercises': 'Alongamentos gerais',
            'series_reps': '',
            'frequency': '3 vezes por semana'
        }
    }

    if fitness_goal not in workout_options:
        return Response({'detail': 'Objetivo de fitness inválido.'}, status=status.HTTP_400_BAD_REQUEST)

    workout_data = workout_options[fitness_goal]
    workout = Workout.objects.create(user=user, **workout_data)

    # Agendar a tarefa para enviar um lembrete de treino após 24 horas
    send_workout_reminder.apply_async((user.id,), countdown=24 * 60 * 60)  # 24 horas

    # Ajustando treino com base no histórico
    historico = Workout.objects.filter(user=user).values("intensity", "series_reps", "carga")
    historico_lista = list(historico)
    for treino in historico_lista:
        if treino.get("carga") is None:
            treino["carga"] = 0
    

    # Ajuste da carga usando a IA
    treino_ajustado = ajustar_treino(historico_lista)
    workout.carga = treino_ajustado.get('carga', 10)


    treino_ajustado = ajustar_treino(historico_lista)
    workout.intensity = treino_ajustado.get('intensity', 'Moderada')
    workout.save()

    serializer = WorkoutSerializer(workout)
    return Response(serializer.data, status=status.HTTP_201_CREATED)

@api_view(['POST'])
def provide_feedback(request):
    user = request.user
    workout_id = request.data.get('workout_id')
    feedback_text = request.data.get('feedback_text')
    rating = request.data.get('rating')

    if not isinstance(rating, int) or rating < 1 or rating > 5:
        return Response({'detail': 'A avaliação deve estar entre 1 e 5.'}, status=status.HTTP_400_BAD_REQUEST)

    try:
        workout = Workout.objects.get(id=workout_id, user=user)
    except Workout.DoesNotExist:
        return Response({'detail': 'Workout não encontrado'}, status=status.HTTP_404_NOT_FOUND)

    feedback = WorkoutFeedback.objects.create(
        user=user,
        workout=workout,
        feedback_text=feedback_text,
        rating=rating
    )

    workout = adjust_workout_based_on_feedback(workout, feedback.rating)
    workout.save()

    return Response({'detail': 'Feedback submitted successfully'}, status=status.HTTP_201_CREATED)

@api_view(['POST'])
def log_workout(request):
    user = request.user
    workout_id = request.data.get('workout_id')
    duration = request.data.get('duration')

    if not duration or not isinstance(duration, (int, float)) or duration <= 0:
        return Response({'detail': 'Duração inválida.'}, status=status.HTTP_400_BAD_REQUEST)

    try:
        workout = Workout.objects.get(id=workout_id, user=user)
    except Workout.DoesNotExist:
        return Response({'detail': 'Workout não encontrado'}, status=status.HTTP_404_NOT_FOUND)

    WorkoutLog.objects.create(
        user=user,
        workout=workout,
        duration=timedelta(minutes=duration)
    )

    return Response({'detail': 'Workout registrado com sucesso'}, status=status.HTTP_201_CREATED)
