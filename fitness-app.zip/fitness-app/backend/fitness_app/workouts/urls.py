from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import generate_workout, log_workout, provide_feedback
from .views import WorkoutViewSet  # Importe o WorkoutViewSet

# Configuração do roteador
router = DefaultRouter()
router.register(r'api', WorkoutViewSet)  # Isso registra a URL do viewset de Workout

urlpatterns = [
    # Endpoints específicos para gerar treino, logar treino e feedback
    path('api/generate/', generate_workout, name='generate_workout'),
    path('api/log/', log_workout, name='log_workout'),
    path('api/feedback/', provide_feedback, name='provide_feedback'),
    
    # Incluindo os endpoints do WorkoutViewSet
    path('', include(router.urls)),
]
# Incluindo as rotas do viewset
urlpatterns += router.urls