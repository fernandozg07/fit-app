from django.db import models
from accounts.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from datetime import timedelta

class Workout(models.Model):

    WORKOUT_TYPES = [
        ('cardio', 'Cardio'),
        ('musculacao', 'Musculação'),
        ('flexibilidade', 'Flexibilidade'),
    ]
    
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='workouts_workouts',  # Nome único para evitar conflito
    )
    workout_type = models.CharField(max_length=100, choices=WORKOUT_TYPES)
    intensity = models.CharField(max_length=50)
    duration = models.DurationField()
    created_at = models.DateTimeField(auto_now_add=True)
    exercises = models.TextField(null=True, blank=True)
    series_reps = models.TextField(null=True, blank=True)
    frequency = models.CharField(max_length=100, null=True, blank=True)
    carga = models.FloatField(null=True, blank=True)  # Campo para carga (peso)

    def __str__(self):
        return f'{self.workout_type} - {self.user.username} - {self.created_at.isoformat()}'
    
class WorkoutLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="workout_logs")
    workout = models.ForeignKey(Workout, on_delete=models.CASCADE, related_name="logs")
    duration = models.DurationField()  
    completed_at = models.DateTimeField(auto_now_add=True)  

    def __str__(self):
        return f'{self.workout.workout_type} - {self.user.username} - {self.completed_at.isoformat()}'

class WorkoutFeedback(models.Model):
    workout = models.ForeignKey(Workout, on_delete=models.CASCADE, related_name="feedbacks")  
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="feedbacks")  
    feedback_text = models.TextField(blank=True)  
    rating = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])  
    created_at = models.DateTimeField(auto_now_add=True)  

    def __str__(self):
        return f'Feedback for {self.workout.workout_type} - {self.user.username} - {self.created_at.isoformat()}'
