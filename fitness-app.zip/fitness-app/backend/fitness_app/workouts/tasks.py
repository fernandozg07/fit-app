from celery import shared_task
from django.contrib.auth import get_user_model
import logging

# Definindo o logger
logger = logging.getLogger(__name__)

@shared_task(bind=True)
def send_workout_reminder(self):
    """
    Task Celery para enviar lembretes diários de treino aos usuários cadastrados.
    """
    try:
        # Busca todos os usuários
        users = get_user_model().objects.all()

        if users.count() == 0:
            logger.info("Nenhum usuário encontrado para enviar lembretes.")
            return "Nenhum usuário encontrado para enviar lembretes."

        # Envia os lembretes para todos os usuários
        for user in users:
            send_reminder(user)

        logger.info(f"Lembrete de treino enviado para {users.count()} usuários.")
        return f"Lembrete de treino enviado para {users.count()} usuários."

    except Exception as e:
        logger.error(f"Erro ao enviar lembretes: {str(e)}")
        self.retry(exc=e, countdown=60)  # Tenta novamente após 60 segundos em caso de erro

def send_reminder(user):
    """
    Função auxiliar para envio do lembrete ao usuário.
    """
    if user.email:
        logger.info(f"Enviando lembrete de treino para {user.email}")
        # Coloque o código para enviar o e-mail aqui
    else:
        logger.warning(f"Usuário {user.id} sem e-mail cadastrado.")
    