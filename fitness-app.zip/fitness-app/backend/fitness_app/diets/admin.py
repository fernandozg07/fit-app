from django.contrib import admin
from .models import Diet, Workout

admin.site.register(Diet)
admin.site.register(Workout)
