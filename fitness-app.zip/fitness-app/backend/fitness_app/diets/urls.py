from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import DietViewSet, generate_diet  # Importando o ViewSet e a função generate_diet

router = DefaultRouter()
router.register(r'diets', DietViewSet)  # Registro do ViewSet para dietas

urlpatterns = [
    # Incluindo as rotas geradas pelo router (API RESTful)
    path('api/', include(router.urls)),  # As rotas que o router gera

    # Endpoint para gerar dieta
    path('api/generate_diet/', generate_diet, name='generate_diet'),
]
