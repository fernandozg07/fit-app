from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status, viewsets
from datetime import timedelta
from random import randint, choice  
from .models import Diet, Workout
from .serializers import DietSerializer, WorkoutSerializer
from ai.trainer import ajustar_treino  # IA para ajustar treino
from rest_framework.permissions import IsAuthenticated


# ViewSet para Diet (CRUD)
class DietViewSet(viewsets.ModelViewSet):
    queryset = Diet.objects.all()
    serializer_class = DietSerializer

@api_view(['POST'])
def generate_diet(request):
    """Gera uma dieta com base no objetivo do usuário."""
    user = request.user
    fitness_goal = request.data.get('fitness_goal')

    if not fitness_goal:
        return Response({'detail': 'Goal não encontrado na requisição.'}, status=status.HTTP_400_BAD_REQUEST)

    diet_config = {
        'perda de peso': {'meals': ['breakfast', 'lunch', 'dinner'], 'calories': (400, 600), 'protein': (30, 50), 'carbs': (40, 60), 'fat': (10, 20)},
        'ganho muscular': {'meals': ['lunch', 'dinner'], 'calories': (700, 900), 'protein': (60, 80), 'carbs': (70, 100), 'fat': (20, 30)},
        'flexibilidade': {'meals': ['snack'], 'calories': (200, 300), 'protein': (10, 20), 'carbs': (30, 50), 'fat': (5, 10)}
    }

    if fitness_goal not in diet_config:
        return Response({'detail': 'Objetivo de dieta inválido.'}, status=status.HTTP_400_BAD_REQUEST)

    config = diet_config[fitness_goal]
    diet = Diet.objects.create(
        user=user,
        meal=choice(config['meals']),
        calories=randint(*config['calories']),
        protein=randint(*config['protein']),
        carbs=randint(*config['carbs']),
        fat=randint(*config['fat'])
    )

    return Response(DietSerializer(diet).data, status=status.HTTP_201_CREATED)

@api_view(['POST'])

def generate_workout(request):
    
    """Gera um treino baseado no objetivo do usuário."""
    user = request.user
    fitness_goal = request.data.get('fitness_goal')

    if not fitness_goal:
        return Response({'detail': 'Goal não encontrado na requisição.'}, status=status.HTTP_400_BAD_REQUEST)

    workout_data = {
        'perda de peso': ('cardio', 'Alta', timedelta(minutes=45), 'Corrida, Bicicleta, Pular corda', '', '5 vezes por semana'),
        'ganho muscular': ('musculacao', 'Moderada', timedelta(hours=1), 'Supino, Agachamento, Levantamento terra, Flexões', '3 séries de 12 repetições por exercício', '3 vezes por semana'),
        'flexibilidade': ('flexibilidade', 'Baixa', timedelta(minutes=30), 'Alongamentos gerais', '', '3 vezes por semana')
    }

    if fitness_goal not in workout_data:
        return Response({'detail': 'Objetivo de fitness inválido.'}, status=status.HTTP_400_BAD_REQUEST)

    workout_type, intensity, duration, exercises, series_reps, frequency = workout_data[fitness_goal]

    workout = Workout.objects.create(
        user=user,
        workout_type=workout_type,
        intensity=intensity,
        duration=duration,
        exercises=exercises,
        series_reps=series_reps,
        frequency=frequency
    )

    historico = list(Workout.objects.filter(user=user).values("intensity", "series_reps", "carga"))

    for treino in historico:
        treino.setdefault("carga", 0)

    treino_ajustado = ajustar_treino(historico)

    workout.intensity = treino_ajustado.get('intensity', 'Moderada')
    workout.save()

    return Response(WorkoutSerializer(workout).data, status=status.HTTP_201_CREATED)
