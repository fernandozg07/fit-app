from rest_framework import serializers
from .models import Diet, Workout
from datetime import timedelta

class DietSerializer(serializers.ModelSerializer):
    class Meta:
        model = Diet
        fields = '__all__'

class WorkoutSerializer(serializers.ModelSerializer):
    duration = serializers.SerializerMethodField()

    class Meta:
        model = Workout
        fields = ['id', 'workout_type', 'intensity', 'duration', 'created_at', 'exercises', 'series_reps', 'frequency']

    def get_duration(self, obj):
        if isinstance(obj.duration, timedelta):
            total_seconds = int(obj.duration.total_seconds())
            hours, remainder = divmod(total_seconds, 3600)
            minutes, _ = divmod(remainder, 60)

            if hours > 0:
                return f"{hours}h {minutes}min"
            return f"{minutes} min"
        return None
